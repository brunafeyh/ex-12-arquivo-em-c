#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <string.h>

typedef struct {
    char caractere;
    int quantidade;
} LETRA;

void inicializarLetras(LETRA letras[], char *caracteres) {
    for (int i = 0; i < 26; i++) {
        letras[i].caractere = *caracteres++;
        letras[i].quantidade = 0;
    }
}

int contarCaracteres(char *nomeArquivo, int *quantidade) {
    FILE *arquivo;
    *quantidade = 0;
    char c;

    arquivo = fopen(nomeArquivo, "r");

    if (arquivo == NULL)
        return errno;

    while ((c = fgetc(arquivo)) != EOF)
        (*quantidade)++;

    (*quantidade)--;

    fclose(arquivo);
    return 0;
}

int contarLinhas(char *nomeArquivo, int *quantidade) {
    FILE *arquivo;
    *quantidade = 0;
    char c;

    arquivo = fopen(nomeArquivo, "r");

    if (arquivo == NULL)
        return errno;

    while ((c = fgetc(arquivo)) != EOF)
        if (c == '\n')
            (*quantidade)++;

    (*quantidade)++;

    fclose(arquivo);
    return 0;
}

int contarPalavras(char *nomeArquivo, int *quantidade) {
    FILE *arquivo;
    char c;

    arquivo = fopen(nomeArquivo, "r");

    if (arquivo == NULL)
        return errno;

    while ((c = fgetc(arquivo)) != EOF)
        if (c == ' ' || c == '\n')
            (*quantidade)++;

    (*quantidade)++;

    fclose(arquivo);
    return 0;
}

int contarLetras(char *nomeArquivo, LETRA letras[]) {
    FILE *arquivo;
    char ch;
    int i;

    arquivo = fopen(nomeArquivo, "r");

    if (arquivo == NULL)
        return errno;

    while ((ch = fgetc(arquivo)) != EOF) {
        for (i = 0; i < 26; i++)
            if (toupper(ch) == letras[i].caractere)
                (letras[i].quantidade)++;
    }

    fclose(arquivo);
    return 0;
}

int gerarRelatorio(char *nomeArquivo, int numCaracteres, int numLinhas, int numPalavras, LETRA letras[]) {
    FILE *arquivo;
    int i;

    arquivo = fopen(nomeArquivo, "a");

    if (arquivo == NULL)
        return errno;

    fprintf(arquivo, "\n\nNúmero de caracteres: %d\n", numCaracteres);
    fprintf(arquivo, "Número de linhas: %d\n", numLinhas);
    fprintf(arquivo, "Número de palavras: %d\n", numPalavras);

    for (i = 0; i < 26; i++) {
        fprintf(arquivo, "%c :", letras[i].caractere);
        fprintf(arquivo, "%d vez(es)\n", letras[i].quantidade);
    }

    fclose(arquivo);
    return 0;
}

int main() {
    int quantCaracteres, quantLinhas, quantPalavras;
    char alfabeto[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    LETRA letras[26];

    contarCaracteres("arquivo.txt", &quantCaracteres);
    contarLinhas("arquivo.txt", &quantLinhas);
    contarPalavras("arquivo.txt", &quantPalavras);
    inicializarLetras(letras, alfabeto);
    contarLetras("arquivo.txt", letras);
    gerarRelatorio("arquivo.txt", quantCaracteres, quantLinhas, quantPalavras, letras);

    return 0;
}
